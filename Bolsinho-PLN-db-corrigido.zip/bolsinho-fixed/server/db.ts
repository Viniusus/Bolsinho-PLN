import { eq, and, gte, lte, desc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import {
  InsertUser, users,
  InsertUserProfile, userProfiles,
  InsertUserMemory, userMemories,
  InsertUserPreference, userPreferences,
  categories, InsertCategory,
  transactions, InsertTransaction,
  budgets, InsertBudget,
  goals, InsertGoal,
  chatMessages, InsertChatMessage,
  alerts, InsertAlert,
  documents, InsertDocument,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

// ─── CONEXÃO LAZY ─────────────────────────────────────────────────────────────
// CORREÇÃO: drizzle(string) é instável com mysql2 — usar pool explícito.
// Isso resolve o erro "Cannot read properties of undefined (reading 'query')"
// que aparecia quando o banco demorava para conectar na inicialização.

let _db: ReturnType<typeof drizzle> | null = null;
let _connecting: Promise<ReturnType<typeof drizzle> | null> | null = null;

export async function getDb() {
  if (_db) return _db;
  if (_connecting) return _connecting;

  _connecting = (async () => {
    const url = ENV.databaseUrl || process.env.DATABASE_URL;
    if (!url) {
      console.warn("[Database] DATABASE_URL não definida — banco indisponível");
      return null;
    }
    try {
      // Pool explícito: mais estável do que passar a string diretamente
      const pool = mysql.createPool({
        uri: url,
        waitForConnections: true,
        connectionLimit: 10,
        connectTimeout: 10_000,
      });
      // Testa a conexão imediatamente para falhar cedo e com mensagem clara
      const conn = await pool.getConnection();
      conn.release();
      _db = drizzle(pool);
      console.log("[Database] Conectado com sucesso");
      return _db;
    } catch (error) {
      console.error("[Database] Falha ao conectar:", error);
      _db = null;
      return null;
    } finally {
      _connecting = null;
    }
  })();

  return _connecting;
}

// ─── USERS ────────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId é obrigatório");

  const db = await getDb();
  if (!db) {
    console.warn("[Database] upsertUser: banco indisponível");
    return;
  }

  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    textFields.forEach((field) => {
      const value = user[field];
      if (value === undefined) return;
      (values as any)[field] = value ?? null;
      updateSet[field] = value ?? null;
    });

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] upsertUser falhou:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0] ?? undefined;
}

// ─── USER PROFILE ─────────────────────────────────────────────────────────────

export async function getUserProfile(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId)).limit(1);
  return result[0] ?? null;
}

export async function upsertUserProfile(profile: InsertUserProfile) {
  const db = await getDb();
  if (!db) { console.warn("[Database] upsertUserProfile: banco indisponível"); return null; }
  if (!profile.userId) throw new Error("userId é obrigatório");

  const values = { userId: profile.userId } as InsertUserProfile & Record<string, unknown>;
  const updateSet: Record<string, unknown> = { updatedAt: new Date() };

  const fields = ["monthlyIncome", "monthlyExpenseLimit", "riskProfile", "financialMoment", "preferredCurrency", "preferredLanguage", "notes"] as const;
  fields.forEach((f) => {
    const v = profile[f];
    if (v !== undefined) { values[f] = v as unknown; updateSet[f] = v; }
  });

  await db.insert(userProfiles).values(values).onDuplicateKeyUpdate({ set: updateSet });
  return getUserProfile(profile.userId);
}

// ─── USER MEMORIES ────────────────────────────────────────────────────────────

export async function getUserMemories(userId: number, limit = 20) {
  const db = await getDb();
  if (!db) return [];
  const safeLimit = Number.isFinite(limit) && limit > 0 ? Math.min(Math.floor(limit), 100) : 20;
  return db.select().from(userMemories)
    .where(and(eq(userMemories.userId, userId), eq(userMemories.isActive, 1)))
    .orderBy(desc(userMemories.importance), desc(userMemories.updatedAt))
    .limit(safeLimit);
}

export async function saveUserMemory(memory: InsertUserMemory) {
  const db = await getDb();
  if (!db) { console.warn("[Database] saveUserMemory: banco indisponível"); return null; }
  if (!memory.userId || !memory.memoryType || !memory.content?.trim()) {
    console.warn("[Database] Memória incompleta ignorada");
    return null;
  }

  const values = {
    userId: memory.userId,
    memoryType: memory.memoryType,
    content: memory.content.trim(),
  } as InsertUserMemory & Record<string, unknown>;

  (["importance", "confidence", "source", "isActive"] as const).forEach((f) => {
    const v = memory[f];
    if (v !== undefined) values[f] = v as unknown;
  });

  const result = await db.insert(userMemories).values(values);
  const id = (result[0] as any).insertId as number;
  const [row] = await db.select().from(userMemories).where(eq(userMemories.id, id)).limit(1);
  return row ?? null;
}

export async function disableUserMemory(userId: number, memoryId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(userMemories)
    .set({ isActive: 0, updatedAt: new Date() })
    .where(and(eq(userMemories.id, memoryId), eq(userMemories.userId, userId)));
}

// ─── USER PREFERENCES ─────────────────────────────────────────────────────────

export async function getUserPreferences(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(userPreferences).where(eq(userPreferences.userId, userId)).orderBy(userPreferences.preferenceKey);
}

export async function upsertUserPreference(userId: number, key: string, value: string) {
  const db = await getDb();
  if (!db) { console.warn("[Database] upsertUserPreference: banco indisponível"); return null; }
  if (!key.trim() || !value.trim()) throw new Error("key e value são obrigatórios");

  await db.insert(userPreferences).values({
    userId,
    preferenceKey: key.trim(),
    preferenceValue: value.trim(),
  }).onDuplicateKeyUpdate({ set: { preferenceValue: value.trim(), updatedAt: new Date() } });

  const [row] = await db.select().from(userPreferences)
    .where(and(eq(userPreferences.userId, userId), eq(userPreferences.preferenceKey, key.trim())))
    .limit(1);
  return row ?? null;
}

// ─── CATEGORIES ───────────────────────────────────────────────────────────────

export async function getUserCategories(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(categories).where(eq(categories.userId, userId)).orderBy(categories.name);
}

export async function createCategory(category: InsertCategory) {
  const db = await getDb();
  if (!db) throw new Error("Banco indisponível");
  const result = await db.insert(categories).values(category);
  const id = (result[0] as any).insertId as number;
  const [row] = await db.select().from(categories).where(eq(categories.id, id)).limit(1);
  return row;
}

// ─── TRANSACTIONS ─────────────────────────────────────────────────────────────

export async function getUserTransactions(userId: number, startDate?: Date, endDate?: Date) {
  const db = await getDb();
  if (!db) return [];

  if (startDate && endDate) {
    return db.select().from(transactions)
      .where(and(eq(transactions.userId, userId), gte(transactions.date, startDate), lte(transactions.date, endDate)))
      .orderBy(desc(transactions.date));
  }
  return db.select().from(transactions)
    .where(eq(transactions.userId, userId))
    .orderBy(desc(transactions.date))
    .limit(100);
}

export async function createTransaction(transaction: InsertTransaction) {
  const db = await getDb();
  if (!db) throw new Error("Banco indisponível");
  const result = await db.insert(transactions).values(transaction);
  const id = (result[0] as any).insertId as number;
  const [row] = await db.select().from(transactions).where(eq(transactions.id, id)).limit(1);
  return row;
}

export async function updateTransaction(id: number, userId: number, data: Partial<InsertTransaction>) {
  const db = await getDb();
  if (!db) throw new Error("Banco indisponível");
  await db.update(transactions).set(data).where(and(eq(transactions.id, id), eq(transactions.userId, userId)));
  const [row] = await db.select().from(transactions).where(and(eq(transactions.id, id), eq(transactions.userId, userId))).limit(1);
  return row ?? null;
}

export async function deleteTransaction(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Banco indisponível");
  await db.delete(transactions).where(and(eq(transactions.id, id), eq(transactions.userId, userId)));
}

// ─── BUDGETS ─────────────────────────────────────────────────────────────────

export async function getUserBudgets(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(budgets).where(eq(budgets.userId, userId)).orderBy(budgets.createdAt);
}

export async function createBudget(budget: InsertBudget) {
  const db = await getDb();
  if (!db) throw new Error("Banco indisponível");
  const result = await db.insert(budgets).values(budget);
  const id = (result[0] as any).insertId as number;
  const [row] = await db.select().from(budgets).where(eq(budgets.id, id)).limit(1);
  return row;
}

// ─── GOALS ───────────────────────────────────────────────────────────────────

export async function getUserGoals(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(goals).where(eq(goals.userId, userId)).orderBy(goals.createdAt);
}

export async function createGoal(goal: InsertGoal) {
  const db = await getDb();
  if (!db) throw new Error("Banco indisponível");
  const result = await db.insert(goals).values(goal);
  const id = (result[0] as any).insertId as number;
  const [row] = await db.select().from(goals).where(eq(goals.id, id)).limit(1);
  return row;
}

// ─── CHAT MESSAGES ────────────────────────────────────────────────────────────

export async function getUserChatMessages(userId: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  // CORREÇÃO: retorna em ordem cronológica (mais antigo primeiro) para o histórico fazer sentido
  const rows = await db.select().from(chatMessages)
    .where(eq(chatMessages.userId, userId))
    .orderBy(desc(chatMessages.createdAt))
    .limit(limit);
  return rows.reverse();
}

export async function createChatMessage(message: InsertChatMessage) {
  const db = await getDb();
  if (!db) throw new Error("Banco indisponível");
  const result = await db.insert(chatMessages).values(message);
  const id = (result[0] as any).insertId as number;
  const [row] = await db.select().from(chatMessages).where(eq(chatMessages.id, id)).limit(1);
  return row;
}

// ─── ALERTS ──────────────────────────────────────────────────────────────────

export async function getUserAlerts(userId: number, onlyUnread = false) {
  const db = await getDb();
  if (!db) return [];
  if (onlyUnread) {
    return db.select().from(alerts).where(and(eq(alerts.userId, userId), eq(alerts.isRead, 0))).orderBy(desc(alerts.createdAt));
  }
  return db.select().from(alerts).where(eq(alerts.userId, userId)).orderBy(desc(alerts.createdAt)).limit(50);
}

export async function createAlert(alert: InsertAlert) {
  const db = await getDb();
  if (!db) throw new Error("Banco indisponível");
  const result = await db.insert(alerts).values(alert);
  const id = (result[0] as any).insertId as number;
  const [row] = await db.select().from(alerts).where(eq(alerts.id, id)).limit(1);
  return row;
}

export async function markAlertRead(alertId: number, userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(alerts).set({ isRead: 1 }).where(and(eq(alerts.id, alertId), eq(alerts.userId, userId)));
}

// ─── DOCUMENTS ───────────────────────────────────────────────────────────────

export async function getUserDocuments(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(documents).where(eq(documents.userId, userId)).orderBy(desc(documents.createdAt));
}

export async function createDocument(document: InsertDocument) {
  const db = await getDb();
  if (!db) throw new Error("Banco indisponível");
  const result = await db.insert(documents).values(document);
  const id = (result[0] as any).insertId as number;
  const [row] = await db.select().from(documents).where(eq(documents.id, id)).limit(1);
  return row;
}

// ─── ANALYTICS ───────────────────────────────────────────────────────────────

export async function getSpendingByCategory(userId: number, startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    categoryId: transactions.categoryId,
    total: sql<number>`SUM(${transactions.amount})`,
    count: sql<number>`COUNT(*)`,
  })
    .from(transactions)
    .where(and(eq(transactions.userId, userId), eq(transactions.type, "expense"), gte(transactions.date, startDate), lte(transactions.date, endDate)))
    .groupBy(transactions.categoryId);
}

// ─── RAG CONTEXT (usado pelo chat para personalizar a IA) ─────────────────────

function fmt(v: number | null | undefined, cur: string | null | undefined) {
  if (v == null) return "não informado";
  const code = cur?.trim().toUpperCase() || "BRL";
  try { return new Intl.NumberFormat("pt-BR", { style: "currency", currency: code }).format(v / 100); }
  catch { return `${code} ${(v / 100).toFixed(2)}`; }
}

function fmtDate(v: Date | string | null | undefined) {
  if (!v) return "não informado";
  const d = v instanceof Date ? v : new Date(v);
  return isNaN(d.getTime()) ? "não informado" : d.toLocaleDateString("pt-BR");
}

function norm(v: string | null | undefined) {
  return v?.trim() || "não informado";
}

export async function getUserRagContext(userId?: number | null): Promise<string> {
  if (!userId) return "";
  try {
    const [profileR, memoriesR, prefsR, goalsR, txR] = await Promise.allSettled([
      getUserProfile(userId),
      getUserMemories(userId, 20),
      getUserPreferences(userId),
      getUserGoals(userId),
      getUserTransactions(userId, undefined, undefined),
    ]);

    const profile = profileR.status === "fulfilled" ? profileR.value : null;
    const memories = memoriesR.status === "fulfilled" ? memoriesR.value : [];
    const prefs = prefsR.status === "fulfilled" ? prefsR.value : [];
    const goalsList = goalsR.status === "fulfilled" ? goalsR.value : [];
    const recentTx = txR.status === "fulfilled" ? (txR.value as any[]).slice(0, 5) : [];

    const profileLines = [
      `- Perfil de risco: ${profile?.riskProfile ?? "não informado"}`,
      `- Momento financeiro: ${profile?.financialMoment ?? "não informado"}`,
      `- Moeda preferida: ${norm(profile?.preferredCurrency)}`,
      `- Idioma preferido: ${norm(profile?.preferredLanguage)}`,
      `- Renda mensal: ${fmt(profile?.monthlyIncome, profile?.preferredCurrency)}`,
      `- Limite mensal: ${fmt(profile?.monthlyExpenseLimit, profile?.preferredCurrency)}`,
      `- Observações: ${norm(profile?.notes)}`,
    ].join("\n");

    const memLines = (memories as any[]).map((m) => `- [${m.memoryType}] ${m.content}`).join("\n") || "- nenhum";
    const prefLines = (prefs as any[]).map((p) => `- ${p.preferenceKey}: ${p.preferenceValue}`).join("\n") || "- nenhum";
    const goalLines = (goalsList as any[]).map((g) => `- ${g.name} | meta ${fmt(g.targetAmount, profile?.preferredCurrency)} | atual ${fmt(g.currentAmount, profile?.preferredCurrency)} | ${g.status}${g.deadline ? ` | prazo ${fmtDate(g.deadline)}` : ""}`).join("\n") || "- nenhum";
    const txLines = recentTx.map((t) => `- ${fmtDate(t.date)} | ${t.type} | ${fmt(t.amount, profile?.preferredCurrency)} | ${t.description}`).join("\n") || "- nenhum";

    return [
      "CONTEXTO PERSISTENTE DO USUÁRIO",
      "",
      "Perfil financeiro:",
      profileLines,
      "",
      "Memórias úteis:",
      memLines,
      "",
      "Preferências:",
      prefLines,
      "",
      "Metas financeiras:",
      goalLines,
      "",
      "Transações recentes:",
      txLines,
    ].join("\n");
  } catch (err) {
    console.warn("[Database] getUserRagContext falhou:", err);
    return "";
  }
}
